﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;

using ApplicationHelloworld.Models;

namespace ApplicationHelloworld.Controllers
{
    public class TestController : ApiController
    {
        Testing[] employees=
        {
            new Testing()
                {
                Id = 1, Name = "John Doe"
                },
                new Testing()
                {
                    Id = 2, Name = "Will Dave"
                },
                new Testing()
                {
                    Id = 3, Name = "Grey John"
                }                
        };
        [ActionName("All")]
        public IEnumerable<Testing> GetAll()
        {
            //Return list of all employees  
            return employees;
        }
        public IHttpActionResult GetDetails(int id)
        {
            //Return a single employee detail  
            var employee = employees.FirstOrDefault(e => e.Id == id);
            if (employee == null)
            {
                throw new HttpResponseException(Request.CreateResponse(HttpStatusCode.NotFound));
            }
            return Ok(employee);
        }
    }
}
